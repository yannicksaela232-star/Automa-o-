package com.vipshop.ussd;

import android.content.Context;
import android.content.SharedPreferences;

public class Config {
    static SharedPreferences p(Context c) { return c.getSharedPreferences("cfg", Context.MODE_PRIVATE); }
    static String servidor(Context c) { return p(c).getString("servidor", ""); }
    static String token(Context c) { return p(c).getString("token", ""); }
    static boolean pronto(Context c) { return !servidor(c).isEmpty() && !token(c).isEmpty(); }
}
