package com.vipshop.ussd;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.telephony.TelephonyManager;

/* Consulta de saldo: *162# -> 8 -> 2 -> envia o texto do ecra ao bot (/api/consulta). */
public class UssdConsulta {
    private final Context ctx;
    private final int slot;
    private final Handler h = new Handler(Looper.getMainLooper());
    private final String[] plano = {"8", "2"};
    private int i = 0;
    private boolean fechado = false;

    UssdConsulta(Context ctx, int slot) {
        this.ctx = ctx;
        this.slot = slot;
    }

    void executar() {
        h.post(() -> enviar("*162#"));
        h.postDelayed(() -> fechar(null), 60000);
    }

    private void enviar(String texto) {
        try {
            TelephonyManager tm = Ussd.tm(ctx, slot);
            if (tm == null) { fechar(null); return; }
            tm.sendUssdRequest(texto, new TelephonyManager.UssdResponseCallback() {
                @Override
                public void onReceiveUssdResponse(TelephonyManager t, String req, CharSequence resp) {
                    if (i < plano.length) enviar(plano[i++]);
                    else fechar(resp == null ? "" : resp.toString());
                }

                @Override
                public void onReceiveUssdResponseFailed(TelephonyManager t, String req, int falha) {
                    fechar(null);
                }
            }, h);
        } catch (Exception e) {
            fechar(null);
        }
    }

    private void fechar(String texto) {
        if (fechado) return;
        fechado = true;
        h.removeCallbacksAndMessages(null);
        if (texto != null) Bot.enviar(ctx, "/api/consulta", texto);
    }
}
