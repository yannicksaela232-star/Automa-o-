package com.vipshop.ussd;

import android.accessibilityservice.AccessibilityService;
import android.os.Bundle;
import android.util.Log;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.Locale;

/* Lê o ecrã do marcador (só janelas do telefone) e preenche/confirma o menu *162#. */
public class Acessibilidade extends AccessibilityService {
    interface Ouvinte { String onTela(String texto); }

    static volatile Ouvinte ouvinte = null;
    private static volatile String ultimo = "";

    static void reiniciar() { ultimo = ""; }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent ev) {
        Ouvinte o = ouvinte;
        if (o == null) return;
        AccessibilityNodeInfo raiz = getRootInActiveWindow();
        if (raiz == null) return;
        StringBuilder sb = new StringBuilder();
        recolher(raiz, sb);
        String texto = sb.toString().trim();
        if (texto.isEmpty() || texto.equals(ultimo)) return;
        ultimo = texto;
        String resposta = o.onTela(texto);
        if (resposta == null) return;
        AccessibilityNodeInfo campo = encontrarCampo(raiz);
        if (campo != null) {
            Bundle args = new Bundle();
            args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, resposta);
            campo.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args);
        }
        AccessibilityNodeInfo botao = encontrarBotao(raiz);
        if (botao != null) botao.performAction(AccessibilityNodeInfo.ACTION_CLICK);
    }

    @Override
    public void onInterrupt() { }

    @Override
    public void onServiceConnected() {
        Log.i("VIP", "acessibilidade ligada");
    }

    private static void recolher(AccessibilityNodeInfo n, StringBuilder sb) {
        if (n == null) return;
        if (n.getText() != null) sb.append(n.getText()).append('\n');
        for (int i = 0; i < n.getChildCount(); i++) recolher(n.getChild(i), sb);
    }

    private static AccessibilityNodeInfo encontrarCampo(AccessibilityNodeInfo n) {
        if (n == null) return null;
        if (n.isEditable()) return n;
        for (int i = 0; i < n.getChildCount(); i++) {
            AccessibilityNodeInfo r = encontrarCampo(n.getChild(i));
            if (r != null) return r;
        }
        return null;
    }

    private static AccessibilityNodeInfo encontrarBotao(AccessibilityNodeInfo n) {
        if (n == null) return null;
        if (n.isClickable() && n.getText() != null) {
            String t = n.getText().toString().toLowerCase(Locale.ROOT);
            if (t.equals("enviar") || t.equals("ok") || t.equals("send") || t.equals("confirmar") || t.equals("sim")) return n;
        }
        for (int i = 0; i < n.getChildCount(); i++) {
            AccessibilityNodeInfo r = encontrarBotao(n.getChild(i));
            if (r != null) return r;
        }
        return null;
    }
}
