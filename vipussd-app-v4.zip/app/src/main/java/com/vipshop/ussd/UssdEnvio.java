package com.vipshop.ussd;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.telephony.TelephonyManager;

import java.util.Locale;

/* Envio de megas: primeiro pela API do Android; se falhar, pela acessibilidade (como o MacroDroid). */
public class UssdEnvio {
    interface Fim { void correu(); }

    private final Context ctx;
    private final int slot;
    private final String codigo, quantidade, numero, restantes;
    private final Fim fim;
    private final Handler h = new Handler(Looper.getMainLooper());
    private int passos = 0;
    private boolean fechado = false;
    private boolean acess = false;

    UssdEnvio(Context ctx, int slot, String codigo, String quantidade, String numero, String restantes, Fim fim) {
        this.ctx = ctx;
        this.slot = slot;
        this.codigo = codigo;
        this.quantidade = quantidade;
        this.numero = numero;
        this.restantes = restantes;
        this.fim = fim;
    }

    void executar() {
        String aviso = "";
        if (restantes != null && !restantes.isEmpty()) {
            if (restantes.equals("0")) aviso = " Esta foi a ultima transferencia deste cartao.";
            else if (restantes.equals("1")) aviso = " Falta 1 transferencia.";
            else aviso = " Faltam " + restantes + " transferencias.";
        }
        Voz.falar(ctx, "A transferir " + quantidade + " megabytes para " + Voz.digitos(numero) + "." + aviso);
        h.postDelayed(() -> fechar(false, "tempo esgotado"), 90000);
        h.post(() -> enviarApi("*162#"));
    }

    private void enviarApi(String texto) {
        try {
            TelephonyManager tm = Ussd.tm(ctx, slot);
            if (tm == null) { usarAcessibilidade(); return; }
            tm.sendUssdRequest(texto, new TelephonyManager.UssdResponseCallback() {
                @Override
                public void onReceiveUssdResponse(TelephonyManager t, String req, CharSequence resp) {
                    String r = proxima(resp == null ? "" : resp.toString());
                    if (r != null) enviarApi(r);
                }

                @Override
                public void onReceiveUssdResponseFailed(TelephonyManager t, String req, int falha) {
                    usarAcessibilidade();
                }
            }, h);
        } catch (Exception e) {
            usarAcessibilidade();
        }
    }

    private void usarAcessibilidade() {
        if (fechado || acess) return;
        acess = true;
        passos = 0;
        Acessibilidade.reiniciar();
        Acessibilidade.ouvinte = this::proxima;
        try {
            Intent i = new Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode("*162#")));
            i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            ctx.startActivity(i);
        } catch (SecurityException e) {
            fechar(false, "sem permissao de chamadas");
        }
    }

    /* Decide a resposta para o texto do ecrã. Devolve null quando termina. */
    private String proxima(String t) {
        if (fechado) return null;
        passos++;
        if (passos > 8) { fechar(false, "menu sem fim"); return null; }
        String n = t.toLowerCase(Locale.ROOT);
        if (n.contains("sucesso") || n.contains("transferid") || n.contains("conclu")) { fechar(true, t); return null; }
        if (n.contains("insuficiente") || n.contains("invalid") || n.contains("erro")) { fechar(false, t); return null; }
        if (n.contains("servi")) return "8";
        if (n.contains("numero") || n.contains("número")) return numero;
        if (n.contains("quantidade") || n.contains("megabyte") || n.contains("mb")) return quantidade;
        if (n.contains("confirm") || n.contains("1. sim") || n.contains("1 - sim")) return "1";
        fechar(false, "menu desconhecido: " + t);
        return null;
    }

    private void fechar(boolean ok, String info) {
        if (fechado) return;
        fechado = true;
        h.removeCallbacksAndMessages(null);
        Acessibilidade.ouvinte = null;
        Voz.falar(ctx, ok ? "Transferencia concluida." : "Falha na transferencia.");
        String motivo = info == null ? "" : (info.length() > 80 ? info.substring(0, 80) : info);
        Api.enviarAsync(ctx, "POST", "/app/resultado?id=" + Ussd.enc(codigo) + "&ok=" + (ok ? "1" : "0") + "&motivo=" + Ussd.enc(motivo), null);
        if (fim != null) fim.correu();
    }
}
